window.stop();
location.href = 'yota.egybest.online' + location.pathname;